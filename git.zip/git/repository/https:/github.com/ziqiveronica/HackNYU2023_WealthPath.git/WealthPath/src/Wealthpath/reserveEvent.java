package Wealthpath;

public class reserveEvent{
	public void  reserveEvent(String eventName, String institutionName, String date, int numAttendees) {
	    // Check if the institution is registered
	    if (!registeredInstitutions.contains(institutionName)) {
	        System.out.println("Error: Institution is not registered");
	        return;
	    }
	    
	    // Check if the event exists
	    Event event = null;
	    for (Event e : institutionEvents.get(institutionName)) {
	        if (e.getName().equals(eventName)) {
	            event = e;
	            break;
	        }
	    }
	    if (event == null) {
	        System.out.println("Error: Event does not exist");
	        return;
	    }
	    
	    // Check if the event is available on the specified date
	    if (!event.isAvailable(date)) {
	        System.out.println("Error: Event is not available on " + date);
	        return;
	    }
	    
	    // Check if there is enough space for the specified number of attendees
	    if (numAttendees > event.getCapacity()) {
	        System.out.println("Error: Not enough space for " + numAttendees + " attendees");
	        return;
	    }
	    
	    // Reserve the event for the specified number of attendees
	    event.reserve(date, numAttendees);
	    
	    // Print confirmation message
	    System.out.println("Event " + eventName + " reserved for " + numAttendees + " attendees on " + date);
	}


}