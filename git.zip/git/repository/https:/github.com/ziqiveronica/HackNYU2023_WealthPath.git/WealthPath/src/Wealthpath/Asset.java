package Wealthpath;

public class Asset {
    private String name;
    private double price;

    public Asset(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return name + " ($" + String.format("%.2f", price) + ")";
    }

	public Object getAssetClass() {
		// TODO Auto-generated method stub
		return null;
	}

	public double getValue() {
		// TODO Auto-generated method stub
		return 0;
	}
}
