package Wealthpath;

import java.util.ArrayList;
import java.util.List;

import Wealthpath.InvestmentExplorer.Bond;
import Wealthpath.InvestmentExplorer.MutualFund;
import Wealthpath.InvestmentExplorer.Stock;

public class Portfolio {
    private List<Asset> assets;
    private double totalValue;
    
    public Portfolio() {
        assets = new ArrayList<>();
        totalValue = 0;
    }
    
    public void addAsset(Asset asset) {
        assets.add(asset);
        totalValue += asset.getValue();
    }
    
    public void removeAsset(Asset asset) {
        assets.remove(asset);
        totalValue -= asset.getValue();
    }
    
    public double getTotalValue() {
        return totalValue;
    }
    
    public List<Asset> getAssets() {
        return assets;
    }
    
    public double getAssetAllocation(String assetClass) {
        double assetClassValue = 0;
        for (Asset asset : assets) {
            if (asset.getAssetClass().equals(assetClass)) {
                assetClassValue += asset.getValue();
            }
        }
        return assetClassValue / totalValue;
    }

	public void addInvestment(Stock stock) {
		// TODO Auto-generated method stub
		
	}

	public void addInvestment(Bond bond) {
		// TODO Auto-generated method stub
		
	}

	public void addInvestmentFund(MutualFund fund) {
		// TODO Auto-generated method stub
		
	}


}

