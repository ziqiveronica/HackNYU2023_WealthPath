package Wealthpath;

import java.util.Scanner;

public class WealthPath {

    public static void main(String[] args) {
        // Initialize Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt user for their name and greet them
        System.out.println("Welcome to WealthPath! Please enter your name:");
        String name = scanner.nextLine();
        System.out.println("Hello, " + name + "!");

        // Prompt user for their age and calculate their retirement age
        System.out.println("How old are you?");
        int age = scanner.nextInt();
        int retirementAge = 65;
        int yearsUntilRetirement = retirementAge - age;
        System.out.println("You will retire in " + yearsUntilRetirement + " years.");

        // Calculate the user's monthly retirement savings goal
        System.out.println("How much money do you want to have saved by the time you retire?");
        double retirementSavingsGoal = scanner.nextDouble();
        double monthlySavingsGoal = retirementSavingsGoal / (yearsUntilRetirement * 12);
        System.out.printf("You need to save $%.2f per month to reach your retirement savings goal.\n", monthlySavingsGoal);

        // Prompt user for their risk tolerance level
        System.out.println("On a scale of 1-10, how risk-tolerant are you?");
        int riskTolerance = scanner.nextInt();

        // Provide investment recommendations based on user's risk tolerance level
        if (riskTolerance >= 8) {
            System.out.println("Based on your high risk tolerance, we recommend investing in high-growth stocks.");
        } else if (riskTolerance >= 5) {
            System.out.println("Based on your moderate risk tolerance, we recommend investing in a diversified portfolio of stocks and bonds.");
        } else {
            System.out.println("Based on your low risk tolerance, we recommend investing in a conservative portfolio of bonds and cash equivalents.");
        }

        // Close Scanner object
        scanner.close();
    }

}



