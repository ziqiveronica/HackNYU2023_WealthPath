package Wealthpath;

public class CompoundingType {

	public double getCompoundingFactor() {
		// TODO Auto-generated method stub
		return 0;
	}

}
