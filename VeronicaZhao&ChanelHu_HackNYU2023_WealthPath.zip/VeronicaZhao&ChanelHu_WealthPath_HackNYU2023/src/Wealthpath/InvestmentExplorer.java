package Wealthpath;

import java.util.List;
import java.util.Scanner;

public class InvestmentExplorer {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String choice;
        do {
            System.out.println("Welcome to the Investment Explorer!");
            System.out.println("Please choose an option:");
            System.out.println("1. Learn about investment vehicles");
            System.out.println("2. Learn about investment tools");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextLine();
            
            switch (choice) {
                case "1":
                    exploreInvestmentVehicles();
                    break;
                case "2":
                    exploreInvestmentTools();
                    break;
                case "3":
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (!choice.equals("3"));
        
        scanner.close();
    }
    
    private static void exploreInvestmentVehicles() {
        System.out.println("Here are some common investment vehicles:");
        System.out.println("1. Stocks");
        System.out.println("2. Bonds");
        System.out.println("3. Mutual Funds");
        System.out.println("4. Exchange-Traded Funds");
        System.out.println("5. Real Estate");
        System.out.println("6. Commodities");
        System.out.print("Enter the number of the investment vehicle to learn more: ");
        
        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();
        
        switch (choice) {
            case 1:
                System.out.println("Stocks are shares of ownership in a company. When you own stock, you own a small piece of the company and have a claim on its assets and earnings.");
                break;
            case 2:
                System.out.println("Bonds are a type of debt security in which an investor lends money to an entity (typically a corporation or government) for a defined period of time at a fixed interest rate.");
                break;
            case 3:
                System.out.println("Mutual funds are a type of investment vehicle that pools money from multiple investors to buy a portfolio of stocks, bonds, or other securities.");
                break;
            case 4:
                System.out.println("Exchange-traded funds (ETFs) are similar to mutual funds in that they hold a basket of stocks, bonds, or other securities. However, ETFs are traded on an exchange like a stock, and their prices can fluctuate throughout the day.");
                break;
            case 5:
                System.out.println("Real estate can be a good investment vehicle because it provides a steady stream of rental income and can appreciate in value over time.");
                break;
            case 6:
                System.out.println("Commodities are physical goods that are traded on an exchange, such as gold, oil, or agricultural products.");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }
        
        scanner.close();
    }
    
    private static void exploreInvestmentTools() {
        System.out.println("Here are some common investment tools:");
        System.out.println("1. Brokerage accounts");
        System.out.println("2. Robo-advisors");
        System.out.println("3. Financial advisors");
        System.out.println("4. Retirement accounts");
        System.out.println("5. Tax-advantaged accounts");
        System.out.print("Enter the number of the investment tool to learn more: ");
        
        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();
        
        switch (choice) {
        	
        };
    }
 // Class representing a tool
    public class Tool {
        private String name;
        private String description;
        private double cost;
        
        public Tool(String name, String description, double cost) {
            this.name = name;
            this.description = description;
            this.cost = cost;
        }
        
        public String getName() {
            return name;
        }
        
        public String getDescription() {
            return description;
        }
        
        public double getCost() {
            return cost;
        }
    }

    // Class representing an investment vehicle
    public abstract class InvestmentVehicle {
        protected String name;
        private String description;
        private double minimumInvestment;
        
        public InvestmentVehicle(String name, String description, double minimumInvestment) {
            this.name = name;
            this.description = description;
            this.minimumInvestment = minimumInvestment;
        }
        
        public String getName() {
            return name;
        }
        
        public String getDescription() {
            return description;
        }
        
        public double getMinimumInvestment() {
            return minimumInvestment;
        }
        
        public abstract double calculateReturns(double investmentAmount, int investmentDuration);
    }

    // Class representing a stock
    public class Stock extends InvestmentVehicle {
        private double stockPrice;
        private double volatility;
        
        public Stock(String name, String description, double minimumInvestment, double stockPrice, double volatility) {
            super(name, description, minimumInvestment);
            this.stockPrice = stockPrice;
            this.volatility = volatility;
        }
        
 

		public String getName() {
        	return name;
        }
        
        public double getStockPrice() {
            return stockPrice;
        }
        
        public double getVolatility() {
            return volatility;
        }
        
        @Override
        public double calculateReturns(double investmentAmount, int investmentDuration) {
            // Formula to calculate returns for a stock investment
            return investmentAmount * Math.pow(1 + stockPrice, investmentDuration) + (volatility * investmentDuration);
        }

		public void setName(String string) {
			// TODO Auto-generated method stub
			
		}

		public void setAllocation(double stockAllocation) {
			// TODO Auto-generated method stub
			
		}

		public void setPrice(double d) {
			// TODO Auto-generated method stub
			
		}

		public void setNumShares(int i) {
			// TODO Auto-generated method stub
			
		}
    }

    // Class representing a bond
    public class Bond extends InvestmentVehicle {
        private double interestRate;
        private int term;
        
        public Bond(String name, String description, double minimumInvestment, double interestRate, int term) {
            super(name, description, minimumInvestment);
            this.interestRate = interestRate;
            this.term = term;
        }
        
  

		public double getInterestRate() {
            return interestRate;
        }
        
        public int getTerm() {
            return term;
        }
        
        @Override
        public double calculateReturns(double investmentAmount, int investmentDuration) {
            // Formula to calculate returns for a bond investment
            return investmentAmount * Math.pow(1 + interestRate, investmentDuration);
        }

		public void setName(String string) {
			// TODO Auto-generated method stub
			
		}

		public void setAllocation(double bondAllocation) {
			// TODO Auto-generated method stub
			
		}

		public void setPrice(double d) {
			// TODO Auto-generated method stub
			
		}

		public void setNumBonds(int i) {
			// TODO Auto-generated method stub
			
		}
    }

    // Class representing a mutual fund
    public class MutualFund extends InvestmentVehicle {
        private double expenseRatio;
        private double expectedReturn;
        
        public MutualFund(String name, String description, double minimumInvestment, double expenseRatio, double expectedReturn) {
            super(name, description, minimumInvestment);
            this.expenseRatio = expenseRatio;
            this.expectedReturn = expectedReturn;
        }
        


		public double getExpenseRatio() {
            return expenseRatio;
        }
        
        public double getExpectedReturn() {
            return expectedReturn;
        }
        
        @Override
        public double calculateReturns(double investmentAmount, int investmentDuration) {
            // Formula to calculate returns for a mutual fund investment
            return investmentAmount * Math.pow(1 + expectedReturn, investmentDuration) - (expenseRatio * investmentAmount);
        }

		public void setName(String string) {
			// TODO Auto-generated method stub
			
		}

		public void setAllocation(double fundAllocation) {
			// TODO Auto-generated method stub
			
		}

		public void setPrice(double d) {
			// TODO Auto-generated method stub
			
		}

		public void setNumShares(int i) {
			// TODO Auto-generated method stub
			
		}
    }

    // Class representing a tool for investment analysis
    public class InvestmentAnalysisTool extends Tool {
        public InvestmentAnalysisTool(String name, String description, double cost) {
			super(name, description, cost);
			// TODO Auto-generated constructor stub
		}

		private List<InvestmentVehicle> availableInvestmentVehicles;
        
        public void InvestmentAnalysisTool(String name) {
        	
        }
    }
    
    
    /**
     * A method that calculates the final value of an investment with a given principal, interest rate, and time period.
     *
     * @param principal     the initial amount of money invested
     * @param interestRate  the annual interest rate, expressed as a decimal
     * @param timePeriod    the number of years the investment is held
     * @param compounding   the frequency with which interest is compounded (e.g., yearly, quarterly, monthly)
     * @return              the final value of the investment
     */
    public double calculateInvestmentValue(double principal, double interestRate, int timePeriod, CompoundingType compounding) {
        double n = compounding.getCompoundingFactor();
        double r = interestRate / n;
        int t = (int) (n * timePeriod);

        return principal * Math.pow(1 + r, t);
    }
    
    

    /**
     * A method that generates a randomized portfolio of investments.
     *
     * @param numStocks     the number of stocks to include in the portfolio
     * @param numBonds      the number of bonds to include in the portfolio
     * @param numFunds      the number of mutual funds to include in the portfolio
     * @param maxAllocation the maximum percentage of the portfolio that can be allocated to any one investment type
     * @return              a Portfolio object containing the randomized investments
     */
    public Portfolio generateRandomizedPortfolio(int numStocks, int numBonds, int numFunds, double maxAllocation) {
        Portfolio portfolio = new Portfolio();

        double stockAllocation = Math.random() * maxAllocation;
        double bondAllocation = Math.random() * maxAllocation;
        double fundAllocation = Math.random() * maxAllocation;

        if (stockAllocation + bondAllocation + fundAllocation > 1) {
            double totalAllocation = stockAllocation + bondAllocation + fundAllocation;
            stockAllocation = stockAllocation / totalAllocation;
            bondAllocation = bondAllocation / totalAllocation;
            fundAllocation = fundAllocation / totalAllocation;
        }

        for (int i = 0; i < numStocks; i++) {
            Stock stock = new Stock();
            stock.setName("Stock " + (i+1));
            stock.setAllocation(stockAllocation);
            stock.setPrice(Math.random() * 100);
            stock.setNumShares((int) (Math.random() * 100));
            portfolio.addInvestment(stock);
        }

        for (int i = 0; i < numBonds; i++) {
            Bond bond = new Bond();
            bond.setName("Bond " + (i+1));
            bond.setAllocation(bondAllocation);
            bond.setPrice(Math.random() * 100);
            bond.setNumBonds((int) (Math.random() * 100));
            portfolio.addInvestment(bond);
        }

        for (int i = 0; i < numFunds; i++) {
            MutualFund fund = new MutualFund();
            fund.setName("Fund " + (i+1));
            fund.setAllocation(fundAllocation);
            fund.setPrice(Math.random() * 100);
            fund.setNumShares((int) (Math.random() * 100));
            portfolio.addInvestmentFund(fund);
        }

        return portfolio;
    }
}


